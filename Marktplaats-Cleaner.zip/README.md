<h1 align="center" id="title">Marktplaats Cleaner</h1>

<p align="center"><img src="https://github.com/MINIX32/Marktplaats-Cleaner/blob/main/icons/logo-128.png" alt="project-image"></p>

<p id="description">Removes ads and other unwanted elements from Marktplaats.</p>

  
  
<h2>🧐 Features</h2>

Here're some of the project's best features:

*   Removes ads
*   Removes "Topadvertenties"
*   Removes "Dagtoppers"
*   Removes businesses
*   Removes sellers with a website
*   Removes annoying sellers
*   Add option to sort on distance without setting distance limit
*   Load more posts per page
*   Ability to turn on/off any of the features

<h2>🛠️ Installation Steps:</h2>

<p>1. Go to <a href="https://addons.mozilla.org/en-US/firefox/addon/marktplaats-cleaner/">Mozilla</a></p>

<p>2. Click install</p>

<p>3. Allow permissions</p>

<p>4. Enjoy!</p>
